-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 27-10-2019 a las 03:27:24
-- Versión del servidor: 10.3.16-MariaDB
-- Versión de PHP: 7.1.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `acueducto`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `direccion`
--

CREATE TABLE `direccion` (
  `id_direccion` int(11) NOT NULL,
  `des_direccion` varchar(255) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `direccion`
--

INSERT INTO `direccion` (`id_direccion`, `des_direccion`) VALUES
(1, 'Barbero-centro'),
(2, 'Barbero-alto'),
(3, 'Barbero-bajo'),
(4, 'Alto San Pedro-Centro'),
(5, 'Alto San Pedro-Alto'),
(6, 'Alto San Pedro-Bajo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `historial_mo`
--

CREATE TABLE `historial_mo` (
  `id_mora` int(11) NOT NULL,
  `id_usu` int(11) NOT NULL,
  `valor_mora` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `concepto` varchar(255) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `historial_mo`
--

INSERT INTO `historial_mo` (`id_mora`, `id_usu`, `valor_mora`, `concepto`) VALUES
(1, 900676316, '$ 120.000', 'año 2016 y proyecto'),
(3, 27089552, '$ 52000', 'FALTA PAGAR 2018');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pago`
--

CREATE TABLE `pago` (
  `id_recibo` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `aa` int(11) NOT NULL,
  `valor` varchar(255) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `pago`
--

INSERT INTO `pago` (`id_recibo`, `id_usuario`, `aa`, `valor`) VALUES
(5, 12969, 2018, '$ 40000'),
(6, 13069207, 2018, '$ 40.000'),
(7, 27089552, 2019, '$ 45.000');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `identificacion` int(11) NOT NULL,
  `nombre` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `conexciones` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `lugar` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`identificacion`, `nombre`, `conexciones`, `lugar`) VALUES
(1805352, 'BOTINA BOTINA  MANUEL JESUS', '1 INST', 2),
(12957524, 'BOTINA JOSE FELIX', '2 INST', 6),
(12969118, 'BOTINA JUAN BAUTISTA', '2 INST. 1 CONS', 2),
(13069052, 'ARTEAGA ALEXANDER ROSALINO', '1 INST', 2),
(13069207, 'BOTINA BOTINA NELSON OSVEIRO', '1 INST', 3),
(27089552, 'BOTINA DE JOJOA MICAELA', '1 INST', 5),
(30718338, 'BOTINA BOTINA MARIA CLARA', '1 INST', 4),
(59824578, 'BOTINA AURA ELISA', '1 INST', 2),
(900676316, 'ASOCIACION AGRO LA LAGUNA', '1 INST. 1CONS', 1),
(1085252373, 'BOTINA LIDIA MARINA', '1 INST', 4),
(1085266653, 'BASTIDAS GUERRERO JOSE FERNANDO', '1 INST', 2),
(1085305461, 'BOTINA FREDY ALEXANDER', '1 INST', 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `us_hi`
--

CREATE TABLE `us_hi` (
  `id_us_hi` int(11) NOT NULL,
  `historia_mo` int(11) NOT NULL,
  `usuario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `us_hi`
--

INSERT INTO `us_hi` (`id_us_hi`, `historia_mo`, `usuario`) VALUES
(1, 1, 900676316),
(2, 3, 27089552);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `valor_ano`
--

CREATE TABLE `valor_ano` (
  `id_ano` int(11) NOT NULL,
  `valor` varchar(255) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `valor_ano`
--

INSERT INTO `valor_ano` (`id_ano`, `valor`) VALUES
(2016, '$ 40000'),
(2017, '$ 40000'),
(2018, '$ 40000'),
(2019, '$ 450000'),
(2020, '$ 45000');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `direccion`
--
ALTER TABLE `direccion`
  ADD PRIMARY KEY (`id_direccion`);

--
-- Indices de la tabla `historial_mo`
--
ALTER TABLE `historial_mo`
  ADD PRIMARY KEY (`id_mora`),
  ADD KEY `id_usu` (`id_usu`);

--
-- Indices de la tabla `pago`
--
ALTER TABLE `pago`
  ADD PRIMARY KEY (`id_recibo`),
  ADD KEY `id_usuario` (`id_usuario`),
  ADD KEY `Año` (`aa`),
  ADD KEY `aa` (`aa`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`identificacion`),
  ADD KEY `lugar` (`lugar`);

--
-- Indices de la tabla `us_hi`
--
ALTER TABLE `us_hi`
  ADD PRIMARY KEY (`id_us_hi`),
  ADD KEY `historia_mo` (`historia_mo`),
  ADD KEY `usuario` (`usuario`);

--
-- Indices de la tabla `valor_ano`
--
ALTER TABLE `valor_ano`
  ADD PRIMARY KEY (`id_ano`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `direccion`
--
ALTER TABLE `direccion`
  MODIFY `id_direccion` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `historial_mo`
--
ALTER TABLE `historial_mo`
  MODIFY `id_mora` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `pago`
--
ALTER TABLE `pago`
  MODIFY `id_recibo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `us_hi`
--
ALTER TABLE `us_hi`
  MODIFY `id_us_hi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `historial_mo`
--
ALTER TABLE `historial_mo`
  ADD CONSTRAINT `historial_mo_ibfk_1` FOREIGN KEY (`id_usu`) REFERENCES `usuarios` (`identificacion`);

--
-- Filtros para la tabla `pago`
--
ALTER TABLE `pago`
  ADD CONSTRAINT `pago_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`identificacion`),
  ADD CONSTRAINT `pago_ibfk_2` FOREIGN KEY (`aa`) REFERENCES `valor_ano` (`id_ano`);

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`lugar`) REFERENCES `direccion` (`id_direccion`);

--
-- Filtros para la tabla `us_hi`
--
ALTER TABLE `us_hi`
  ADD CONSTRAINT `us_hi_ibfk_1` FOREIGN KEY (`historia_mo`) REFERENCES `historial_mo` (`id_mora`),
  ADD CONSTRAINT `us_hi_ibfk_2` FOREIGN KEY (`usuario`) REFERENCES `usuarios` (`identificacion`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
