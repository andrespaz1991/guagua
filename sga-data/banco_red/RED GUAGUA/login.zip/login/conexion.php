<?php //abrimos etiqueta php
$mysqli = new mysqli ('localhost','root','','login') ;  
//  $nombre_variable_de_conexion=nueva conexion ('servidor','usuario','contraseña','base_de_datos');  -->
        if (mysqli_connect_errno()){ //si se rpesenta un error de conexion
        echo "error";//presenta mensaje de error
                                    } //cierra condición de precencia de error
        elseif ($mysqli) { //en caso de realizar la conexion
        mysqli_set_charset($mysqli,'utf-8'); //convierte nnuestros caracteres con codificación utf-8 
                                    }//cerramos condición de existencia de conexion;}
                                    ?> <!-- cerramos nuestra etiqueta php   -->
