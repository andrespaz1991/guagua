<?php
if (isset($_POST['usuario'],$_POST['clave']))   { //comprobamos si por el metodo POST  la variable ususario y clave estan definidas
    require 'conexion.php'; //llamamos al archivo de conexion para establecer conexion con nuestra base de datos
    $usuario = $mysqli -> real_escape_string($_POST['usuario']); //utilizamos una buena practica de seguridad a traves de $mysqli -> real_escape_string() que nos permite evitar accesos no autorizados 
    $clave = $mysqli -> real_escape_string($_POST['clave']);//utilizamos una buena practica de seguridad a traves de $mysqli -> real_escape_string() que nos permite evitar accesos no autorizados 
    $contaseña_cifrada = sha1($clave);//ciframos o encriptamos nuestra clave para brindar nuestra clave 
   $sql='select * from usuario where clave ="'.$contaseña_cifrada.'" and usuario="'.$usuario.'"';//guardmos en la variable $sql la consulta de base de datos en la cual preguntaremos si el usuario y clave ingresado por el usuario se encuentra en base de datos
    $consultar_usuario = $mysqli ->query ($sql); //enviamos a traves de la variable $msyqli de nuestro archivo de conexion y la función query nuestro mensaje de la linea anterior a base de datod
        if ($consultar_usuario->num_rows){ //obtenemos el numero de filas de la consulta anterior
            if ($row=$consultar_usuario ->fetch_Assoc()  ){//obetenemos una fila de nuestra consulta anterior
          //  Una sesión es una forma de almacenar la información en variables para ser utilizado a través de múltiples páginas u archivos
                 session_start(); //para utilizar variables de session es necesario escribir primero  session_start(); para iniciar o continuar utilizando las variables de session
                $_SESSION['identificacion_usuario']=$row['identificacion_usuario']; // de la siguiente forma utilizamos una variable de session $_SESSION['nombre_variable_de_session'] y en ella almacenamos el valor consultado de la identificación  de nuestro usuario $row['identificacion_usuario']; 
                $_SESSION['nombre_usuario']=$row['nombre_usuario']; //creamos y asignamos en la variable de session $_SESSION['nombre_usuario']el nombre nuestro usuario =$row['nombre_usuario'];
                 header ('location:bienvenido.php');//redireccionamos a nuestro archivo bienvenido.php a traves de  header ('location:bienvenido.php');
                                                            }//cerramos la llave de la linea if ($row=$consultar_usuario ->fetch_Assoc()  ){
                                            }//cerramos la llave de la linea if ($row=$consultar_usuario ->fetch_Assoc()  ){
            else {//en caso de no encontrar el usuario y(o) su clave 
                echo 'Por favor verifique su información';//muestra el mensaje de verificación de información 
                 }//cerramos la llave de la condición else 
                                                                    }//cerramos la llave de la condición if (isset($_POST['usuario'],$_POST['clave']))   {
    ?>




