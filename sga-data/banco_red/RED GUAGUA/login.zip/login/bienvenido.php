<!DOCTYPE html><!-- Línea que le permite al navegador saber que la pagina es HTML5 -->
<html lang="es"><!-- Definimos con lang el idioma de preferencia -->
<head><!-- la Cabecera nos permite tener la información que no hace parte del documento -->
	<meta charset="UTF-8"><!-- indica la tabla de caracteres que debe utilizar (ñ, etc..)-->
	<title>Bienvenido</title><!-- nombre de la barra de título de la pagina-->
</head><!-- Cerramos la Cabecera-->
<body><!--contiene lo que se muestra en la ventana del navegador -->
<?php //abrimos nuestra etiqueta de php
session_start();//utilizamos session_start(); para utilizar nuestras variables de session
if (isset($_SESSION['nombre_usuario'])){?> <!-- Comprobamos la si la variable de session $_SESSION['nombre_usuario']esta definida   -->
	<h1>Bienvenido <?php echo $_SESSION['nombre_usuario'];?> </h1> <!-- Mostramos a traves de una etiqueta de titulo el nombre de nuestro usuario a traves de la variable de session $_SESSION['nombre_usuario'] -->
    									<?php }// cerramos nuestra condición if (isset($_SESSION['nombre_usuario'])){ 
else { // en caso de no haber encontrado a nuestro usuario
	header ('location:index.php');//redireccionamos a nuestro archivo index.php a traves de  header ('location:index.php') para que el usuario se pueda identificar
	}  //cerramos nuestra condición de else  									
    									?> <!-- cerramos nuestra etiqueta php -->
</body><!--Cerramos el cuerpo del documento-->
</html><!--Cerramos la etiqueta de html del  documento-->
