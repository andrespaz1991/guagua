<!DOCTYPE html><!-- Línea que le permite al navegador saber que la pagina es HTML5 -->
<html lang="es"> <!-- Definimos con lang el idioma de preferencia -->
<head> <!-- la Cabecera nos permite tener la información que no hace parte del documento -->
	<meta charset="UTF-8"> <!-- indica la tabla de caracteres que debe utilizar (ñ, etc..)-->
	<title>Login</title> <!-- nombre de la barra de título de la pagina-->

</head><!-- Cerramos la Cabecera-->
<body> <!--contiene lo que se muestra en la ventana del navegador -->
    
        <form action="validar.php" method="POST"  ><!--Creamos un formulario para guardar los campos -->
<label for="">Usuario</label>
<input Placeholder="Ingresar usuario" required type="text" name="usuario"/><br><!--Creamos el campo Usuario -->
<label for="">Clave</label>
<input Placeholder="Ingresar clave" required type="password" name="clave"/><br><!--Creamos el campo Usuario -->
<input required type="submit" name="ingresar" Value ="ingresar"/><!--Creamos button para enviar -->
        </form><!--Cerramos el formulario-->
        
</body><!-- Cerramos el cuerpo del documento-->
</html><!-- Cerramos la etiqueta de html del  documento-->
